﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMLDiagframApp.Entities
{
	public partial class Test
	{
	}
	public partial class Test:Foo
	{
	}

	public class Foo
	{

	}
}
