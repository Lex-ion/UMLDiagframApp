﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMLDiagframApp.Entities
{
    public enum ModifiersEnum
    {
        Public = 0,
        Private = 1,
        Protected = 2,
        Internal = 4

    }
}
